package com.hendog.economy;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.UUID;

/** Admin tools: /eco give|take|set|reset <player> [amount] and /eco reload */
final class EcoCommand implements TabExecutor {
    private static final String[] SUBS = {"give", "take", "set", "reset", "reload"};
    private final HendogEconomyPlugin plugin;

    EcoCommand(HendogEconomyPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Messages msg = plugin.messages();
        EconomyService eco = plugin.economy();
        if (!sender.hasPermission("hendogeconomy.admin")) {
            msg.send(sender, "no-permission");
            return true;
        }
        if (args.length == 0) {
            msg.send(sender, "usage-eco");
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("reload")) {
            plugin.reloadAll();
            msg.send(sender, "eco-reloaded");
            return true;
        }
        if (args.length < 2 || !(sub.equals("give") || sub.equals("take") || sub.equals("set") || sub.equals("reset"))) {
            msg.send(sender, "usage-eco");
            return true;
        }
        Optional<UUID> id = eco.find(args[1]);
        if (id.isEmpty()) {
            Player online = Bukkit.getPlayerExact(args[1]);
            if (online != null) {
                eco.ensureAccount(online.getUniqueId(), online.getName());
                id = Optional.of(online.getUniqueId());
            }
        }
        if (id.isEmpty()) {
            msg.send(sender, "player-not-found", "player", args[1]);
            return true;
        }
        UUID target = id.get();
        String name = eco.nameOf(target);
        long amount = 0;
        if (!sub.equals("reset")) {
            if (args.length < 3) {
                msg.send(sender, "usage-eco");
                return true;
            }
            OptionalLong parsed = Money.parse(args[2]);
            if (parsed.isEmpty() || (parsed.getAsLong() == 0 && !sub.equals("set"))) {
                msg.send(sender, "invalid-amount");
                return true;
            }
            amount = parsed.getAsLong();
        }
        EconomyService.Result r;
        String key;
        switch (sub) {
            case "give" -> { r = eco.deposit(target, amount); key = "eco-gave"; }
            case "take" -> { r = eco.withdraw(target, amount); key = "eco-took"; }
            case "set" -> { r = eco.set(target, amount); key = "eco-set"; }
            default -> { amount = eco.startingBalance(); r = eco.set(target, amount); key = "eco-reset"; }
        }
        switch (r) {
            case OK -> {
                msg.send(sender, key, "amount", plugin.money(amount), "player", name);
                plugin.txLog().log("ECO " + sub.toUpperCase(Locale.ROOT) + " by " + sender.getName() + " on " + name + " " + amount);
            }
            case INSUFFICIENT -> msg.send(sender, "insufficient");
            case MAX_BALANCE -> msg.send(sender, "max-balance", "player", name);
            default -> msg.send(sender, "invalid-amount");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("hendogeconomy.admin")) return out;
        if (args.length == 1) {
            for (String s : SUBS) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && !args[0].equalsIgnoreCase("reload")) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) out.add(p.getName());
        }
        return out;
    }
}
