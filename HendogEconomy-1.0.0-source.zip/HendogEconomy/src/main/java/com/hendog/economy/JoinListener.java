package com.hendog.economy;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

/** Gives every new player an account and keeps names up to date so /pay and /bal work by name. */
final class JoinListener implements Listener {
    private final HendogEconomyPlugin plugin;

    JoinListener(HendogEconomyPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        boolean created = plugin.economy().ensureAccount(p.getUniqueId(), p.getName());
        if (created) {
            plugin.messages().send(p, "first-join", "amount", plugin.money(plugin.economy().balance(p.getUniqueId())));
        }
    }
}
