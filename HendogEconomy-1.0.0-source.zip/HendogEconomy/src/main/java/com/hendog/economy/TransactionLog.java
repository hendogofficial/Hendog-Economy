package com.hendog.economy;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Appends one line per money movement so staff can investigate dupes and scams. */
public final class TransactionLog {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final Path file;
    private final boolean enabled;

    public TransactionLog(Path file, boolean enabled) {
        this.file = file;
        this.enabled = enabled;
    }

    public synchronized void log(String line) {
        if (!enabled) return;
        try {
            Files.writeString(file, LocalDateTime.now().format(FMT) + " " + line + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) {
            // logging must never break a payment
        }
    }
}
