package com.hendog.economy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Map;

/** All chat text lives in config.yml (MiniMessage format) so you can restyle it without touching code. */
final class Messages {
    private static final Map<String, String> DEFAULTS = Map.ofEntries(
            Map.entry("no-permission", "<red>You don't have permission to do that."),
            Map.entry("players-only", "<red>Only players can use this command."),
            Map.entry("usage-pay", "<red>Usage: /pay [player] [amount]  <gray>(try 1k, 2.5m, 1b, half, all)"),
            Map.entry("usage-eco", "<red>Usage: /eco [give|take|set|reset|reload] [player] [amount]"),
            Map.entry("player-not-found", "<red>%player% has never joined this server."),
            Map.entry("invalid-amount", "<red>That's not a valid amount. Use whole dollars like 500, 10k, 2.5m or 1b."),
            Map.entry("cant-pay-self", "<red>You can't pay yourself."),
            Map.entry("insufficient", "<red>You don't have enough money."),
            Map.entry("below-min", "<red>The minimum payment is $%amount%."),
            Map.entry("max-balance", "<red>%player% can't hold that much money."),
            Map.entry("paid-sender", "<green>You paid $%amount% to %player%."),
            Map.entry("paid-receiver", "<green>%player% paid you $%amount%."),
            Map.entry("balance-self", "<green>Balance: <white>$%amount%</white><gray>%exact%"),
            Map.entry("balance-other", "<green>%player%'s balance: <white>$%amount%</white><gray>%exact%"),
            Map.entry("baltop-header", "<gold><bold>Top balances</bold> <gray>(page %page%/%pages%)"),
            Map.entry("baltop-line", "<yellow>#%rank% <white>%player% <green>$%amount%"),
            Map.entry("baltop-empty", "<gray>Nobody has an account yet."),
            Map.entry("first-join", "<green>Welcome! You start with <white>$%amount%</white>."),
            Map.entry("eco-gave", "<green>Gave $%amount% to %player%."),
            Map.entry("eco-took", "<green>Took $%amount% from %player%."),
            Map.entry("eco-set", "<green>Set %player%'s balance to $%amount%."),
            Map.entry("eco-reset", "<green>Reset %player%'s balance to $%amount%."),
            Map.entry("eco-reloaded", "<green>HendogEconomy config reloaded.")
    );

    private final JavaPlugin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();

    Messages(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    private String raw(String key) {
        String v = plugin.getConfig().getString("messages." + key, null);
        return v != null ? v : DEFAULTS.getOrDefault(key, key);
    }

    /** kv = alternating placeholder name and value, e.g. render("paid-sender", "amount", "5M", "player", "Bob"). */
    Component render(String key, String... kv) {
        String s = raw(key);
        for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace("%" + kv[i] + "%", kv[i + 1]);
        return mm.deserialize(s);
    }

    void send(CommandSender to, String key, String... kv) {
        to.sendMessage(render(key, kv));
    }
}
