package com.hendog.economy;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * The money brain. No Minecraft code in here, so it is easy to test and other plugins can use it.
 * Every method is thread-safe.
 */
public final class EconomyService {
    public enum Result { OK, NO_ACCOUNT, INSUFFICIENT, INVALID_AMOUNT, MAX_BALANCE, SELF }

    public record Row(UUID id, String name, long balance) {}

    private final Object lock = new Object();
    private final Map<UUID, Long> balances = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final Map<String, UUID> byName = new HashMap<>();   // lower-case name -> uuid
    private volatile long startingBalance;
    private volatile long maxBalance;
    private volatile boolean dirty;

    public EconomyService(long startingBalance, long maxBalance) {
        configure(startingBalance, maxBalance);
    }

    public void configure(long startingBalance, long maxBalance) {
        this.maxBalance = Math.max(0, maxBalance);
        this.startingBalance = Math.max(0, Math.min(startingBalance, this.maxBalance));
    }

    public long startingBalance() { return startingBalance; }
    public long maxBalance() { return maxBalance; }

    // ---------------------------------------------------------------- accounts
    /** Creates the account if needed and keeps the player's name up to date. Returns true if a new account was created. */
    public boolean ensureAccount(UUID id, String name) {
        synchronized (lock) {
            boolean created = false;
            if (!balances.containsKey(id)) {
                balances.put(id, startingBalance);
                created = true;
                dirty = true;
            }
            updateName(id, name);
            return created;
        }
    }

    private void updateName(UUID id, String name) {
        if (name == null || name.isBlank()) return;
        String lower = name.toLowerCase(Locale.ROOT);
        String old = names.get(id);
        if (name.equals(old)) {
            byName.put(lower, id);
            return;
        }
        if (old != null) byName.remove(old.toLowerCase(Locale.ROOT), id);
        names.put(id, name);
        byName.put(lower, id);          // if someone else used this name before, the newest holder wins
        dirty = true;
    }

    public boolean hasAccount(UUID id) {
        synchronized (lock) { return balances.containsKey(id); }
    }

    public Optional<UUID> find(String name) {
        if (name == null) return Optional.empty();
        synchronized (lock) { return Optional.ofNullable(byName.get(name.toLowerCase(Locale.ROOT))); }
    }

    public String nameOf(UUID id) {
        synchronized (lock) {
            String n = names.get(id);
            return n != null ? n : id.toString();
        }
    }

    public int count() {
        synchronized (lock) { return balances.size(); }
    }

    // ---------------------------------------------------------------- money
    public long balance(UUID id) {
        synchronized (lock) { return balances.getOrDefault(id, 0L); }
    }

    public boolean has(UUID id, long amount) {
        synchronized (lock) { return balances.getOrDefault(id, 0L) >= amount; }
    }

    public Result deposit(UUID id, long amount) {
        if (amount <= 0) return Result.INVALID_AMOUNT;
        synchronized (lock) {
            Long b = balances.get(id);
            if (b == null) return Result.NO_ACCOUNT;
            if (b > maxBalance - amount) return Result.MAX_BALANCE;
            balances.put(id, b + amount);
            dirty = true;
            return Result.OK;
        }
    }

    public Result withdraw(UUID id, long amount) {
        if (amount <= 0) return Result.INVALID_AMOUNT;
        synchronized (lock) {
            Long b = balances.get(id);
            if (b == null) return Result.NO_ACCOUNT;
            if (b < amount) return Result.INSUFFICIENT;
            balances.put(id, b - amount);
            dirty = true;
            return Result.OK;
        }
    }

    public Result set(UUID id, long amount) {
        if (amount < 0 || amount > maxBalance) return Result.INVALID_AMOUNT;
        synchronized (lock) {
            if (!balances.containsKey(id)) return Result.NO_ACCOUNT;
            balances.put(id, amount);
            dirty = true;
            return Result.OK;
        }
    }

    /** Moves money atomically: either both sides change or nothing does. */
    public Result transfer(UUID from, UUID to, long amount) {
        if (amount <= 0) return Result.INVALID_AMOUNT;
        if (from.equals(to)) return Result.SELF;
        synchronized (lock) {
            Long fb = balances.get(from);
            Long tb = balances.get(to);
            if (fb == null || tb == null) return Result.NO_ACCOUNT;
            if (fb < amount) return Result.INSUFFICIENT;
            if (tb > maxBalance - amount) return Result.MAX_BALANCE;
            balances.put(from, fb - amount);
            balances.put(to, tb + amount);
            dirty = true;
            return Result.OK;
        }
    }

    // ---------------------------------------------------------------- leaderboard
    public List<Row> top(int offset, int limit) {
        List<Row> all = snapshot();
        all.sort(Comparator.comparingLong(Row::balance).reversed().thenComparing(r -> r.name().toLowerCase(Locale.ROOT)));
        int from = Math.min(Math.max(0, offset), all.size());
        int to = Math.min(all.size(), from + Math.max(0, limit));
        return new ArrayList<>(all.subList(from, to));
    }

    // ---------------------------------------------------------------- saving support
    public List<Row> snapshot() {
        synchronized (lock) {
            List<Row> rows = new ArrayList<>(balances.size());
            for (Map.Entry<UUID, Long> e : balances.entrySet()) rows.add(new Row(e.getKey(), nameOf(e.getKey()), e.getValue()));
            return rows;
        }
    }

    public void load(List<Row> rows) {
        synchronized (lock) {
            balances.clear(); names.clear(); byName.clear();
            for (Row r : rows) {
                balances.put(r.id(), Math.max(0, r.balance()));
                if (r.name() != null && !r.name().isBlank() && !r.name().equals(r.id().toString())) {
                    names.put(r.id(), r.name());
                    byName.put(r.name().toLowerCase(Locale.ROOT), r.id());
                }
            }
            dirty = false;
        }
    }

    /** True if something changed since the last save. Resets the flag. */
    public boolean consumeDirty() {
        synchronized (lock) {
            boolean d = dirty;
            dirty = false;
            return d;
        }
    }

    public void markDirty() { dirty = true; }
}
