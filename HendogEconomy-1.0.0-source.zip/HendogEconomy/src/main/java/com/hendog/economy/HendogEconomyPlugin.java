package com.hendog.economy;

import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.IOException;
import java.nio.file.Path;

/**
 * HendogEconomy - balances, /pay, /baltop and admin tools.
 * Other plugins you write later can use the money through {@link #economy()} (see README).
 */
public final class HendogEconomyPlugin extends JavaPlugin {
    private static HendogEconomyPlugin instance;

    private EconomyService economy;
    private Messages messages;
    private TransactionLog txLog;
    private Path dataFile;
    private BukkitTask autosave;
    private final Object saveLock = new Object();
    private volatile boolean showExact;
    private volatile long minPay;

    /** For other plugins: HendogEconomyPlugin.get().economy().deposit(uuid, amount) */
    public static HendogEconomyPlugin get() {
        return instance;
    }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        economy = new EconomyService(1000, Long.MAX_VALUE);
        dataFile = getDataFolder().toPath().resolve("balances.tsv");
        applySettings();
        try {
            Storage.LoadResult loaded = Storage.load(dataFile);
            economy.load(loaded.rows);
            getLogger().info("Loaded " + loaded.rows.size() + " accounts.");
            if (loaded.skipped > 0) getLogger().warning("Skipped " + loaded.skipped + " unreadable lines in balances.tsv (a .bak backup is kept on every save).");
        } catch (IOException e) {
            // Refuse to start rather than risk overwriting everyone's money with an empty file.
            getLogger().severe("Could not read balances.tsv - disabling to protect your data: " + e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        messages = new Messages(this);
        bind("bal", new BalCommand(this));
        bind("pay", new PayCommand(this));
        bind("baltop", new BalTopCommand(this));
        bind("eco", new EcoCommand(this));
        getServer().getPluginManager().registerEvents(new JoinListener(this), this);
        long ticks = Math.max(1, getConfig().getInt("autosave-minutes", 5)) * 60L * 20L;
        autosave = getServer().getScheduler().runTaskTimerAsynchronously(this, this::saveIfDirty, ticks, ticks);
        getLogger().info("HendogEconomy enabled.");
    }

    @Override
    public void onDisable() {
        if (autosave != null) autosave.cancel();
        if (economy != null && dataFile != null) saveIfDirty();
        instance = null;
    }

    private void bind(String name, CommandExecutor executor) {
        PluginCommand cmd = getCommand(name);
        if (cmd != null) cmd.setExecutor(executor);
        else getLogger().warning("Command /" + name + " is missing from plugin.yml");
    }

    private void applySettings() {
        long start = getConfig().getLong("starting-balance", 1000L);
        long max = getConfig().getLong("max-balance", 999_999_999_999_999L);
        economy.configure(start, max);
        minPay = Math.max(1, getConfig().getLong("min-pay", 1L));
        showExact = getConfig().getBoolean("show-exact-balance", true);
        txLog = new TransactionLog(getDataFolder().toPath().resolve("transactions.log"), getConfig().getBoolean("log-transactions", true));
    }

    /** /eco reload */
    void reloadAll() {
        reloadConfig();
        applySettings();
    }

    /** Safe to call from any thread. Only writes the file if something changed. */
    void saveIfDirty() {
        synchronized (saveLock) {
            if (!economy.consumeDirty()) return;
            try {
                Storage.save(dataFile, economy.snapshot());
            } catch (IOException e) {
                economy.markDirty();
                getLogger().severe("Could not save balances.tsv: " + e);
            }
        }
    }

    // ---- small helpers used by the commands
    public EconomyService economy() { return economy; }
    Messages messages() { return messages; }
    TransactionLog txLog() { return txLog; }
    long minPay() { return minPay; }
    String money(long v) { return Money.shortFormat(v); }
    String exactSuffix(long v) { return showExact && v >= 1000 ? " (" + Money.exact(v) + ")" : ""; }
}
