package com.hendog.economy;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;
import java.util.OptionalLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Parsing and formatting of money: "1.5b", "350M", "10k", "1,000,000", "$5m". Whole dollars only. */
public final class Money {
    private static final Pattern INPUT = Pattern.compile("^\\$?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?|\\.[0-9]+)\\s*([kmbt])?$", Pattern.CASE_INSENSITIVE);
    private static final long[] UNITS = {1_000L, 1_000_000L, 1_000_000_000L, 1_000_000_000_000L};
    private static final char[] SUFFIX = {'K', 'M', 'B', 'T'};
    private static final BigDecimal LONG_MAX = BigDecimal.valueOf(Long.MAX_VALUE);

    private Money() {}

    /** Returns the amount in whole dollars, or empty if the text is not a valid amount (negative, fractional dollars, too big...). */
    public static OptionalLong parse(String text) {
        if (text == null) return OptionalLong.empty();
        String t = text.trim();
        if (t.isEmpty() || t.length() > 40) return OptionalLong.empty();
        Matcher m = INPUT.matcher(t);
        if (!m.matches()) return OptionalLong.empty();
        BigDecimal v;
        try {
            v = new BigDecimal(m.group(1).replace(",", ""));
        } catch (NumberFormatException e) {
            return OptionalLong.empty();
        }
        if (m.group(2) != null) {
            char s = Character.toUpperCase(m.group(2).charAt(0));
            for (int i = 0; i < SUFFIX.length; i++) {
                if (SUFFIX[i] == s) v = v.multiply(BigDecimal.valueOf(UNITS[i]));
            }
        }
        v = v.stripTrailingZeros();
        if (v.scale() > 0) return OptionalLong.empty();       // e.g. 1.5 or 1.2345k -> not whole dollars
        if (v.compareTo(LONG_MAX) > 0) return OptionalLong.empty();
        return OptionalLong.of(v.longValueExact());
    }

    /** 43_200_000_000 -> "43.2B". Always rounds DOWN so a player is never shown more than they have. */
    public static String shortFormat(long value) {
        if (value < 0) return value == Long.MIN_VALUE ? "-" + shortFormat(Long.MAX_VALUE) : "-" + shortFormat(-value);
        if (value < 1000) return Long.toString(value);
        int i = 0;
        while (i + 1 < UNITS.length && value >= UNITS[i + 1]) i++;
        BigDecimal d = BigDecimal.valueOf(value).divide(BigDecimal.valueOf(UNITS[i]), 1, RoundingMode.DOWN).stripTrailingZeros();
        String plain = d.toPlainString();
        if (i == UNITS.length - 1) {                           // trillions can be 1000+: add commas
            int dot = plain.indexOf('.');
            String whole = dot < 0 ? plain : plain.substring(0, dot);
            String frac = dot < 0 ? "" : plain.substring(dot);
            plain = String.format(Locale.US, "%,d", Long.parseLong(whole)) + frac;
        }
        return plain + SUFFIX[i];
    }

    /** 43200000000 -> "43,200,000,000" */
    public static String exact(long value) {
        return String.format(Locale.US, "%,d", value);
    }
}
