package com.hendog.economy;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.UUID;

/** /pay <player> <amount>   (amount: 500, 10k, 2.5m, 1b, half, all) */
final class PayCommand implements TabExecutor {
    private static final String[] SUGGESTIONS = {"1k", "10k", "100k", "1m", "10m", "100m", "1b", "half", "all"};
    private final HendogEconomyPlugin plugin;

    PayCommand(HendogEconomyPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Messages msg = plugin.messages();
        EconomyService eco = plugin.economy();
        if (!(sender instanceof Player p)) {
            msg.send(sender, "players-only");
            return true;
        }
        if (args.length != 2) {
            msg.send(sender, "usage-pay");
            return true;
        }
        Optional<UUID> to = eco.find(args[0]);
        if (to.isEmpty()) {
            msg.send(sender, "player-not-found", "player", args[0]);
            return true;
        }
        UUID from = p.getUniqueId();
        if (to.get().equals(from)) {
            msg.send(sender, "cant-pay-self");
            return true;
        }
        long amount;
        String word = args[1].toLowerCase(Locale.ROOT);
        if (word.equals("all")) {
            amount = eco.balance(from);
        } else if (word.equals("half")) {
            amount = eco.balance(from) / 2;
        } else {
            OptionalLong parsed = Money.parse(args[1]);
            if (parsed.isEmpty()) {
                msg.send(sender, "invalid-amount");
                return true;
            }
            amount = parsed.getAsLong();
        }
        if (amount <= 0) {
            msg.send(sender, "invalid-amount");
            return true;
        }
        if (amount < plugin.minPay()) {
            msg.send(sender, "below-min", "amount", plugin.money(plugin.minPay()));
            return true;
        }
        String toName = eco.nameOf(to.get());
        EconomyService.Result r = eco.transfer(from, to.get(), amount);
        switch (r) {
            case OK -> {
                msg.send(sender, "paid-sender", "amount", plugin.money(amount), "player", toName);
                Player receiver = Bukkit.getPlayer(to.get());
                if (receiver != null) msg.send(receiver, "paid-receiver", "amount", plugin.money(amount), "player", p.getName());
                plugin.txLog().log("PAY " + p.getName() + " -> " + toName + " " + amount);
            }
            case INSUFFICIENT -> msg.send(sender, "insufficient");
            case MAX_BALANCE -> msg.send(sender, "max-balance", "player", toName);
            case SELF -> msg.send(sender, "cant-pay-self");
            default -> msg.send(sender, "invalid-amount");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) out.add(p.getName());
            }
        } else if (args.length == 2) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            for (String s : SUGGESTIONS) if (s.startsWith(prefix)) out.add(s);
        }
        return out;
    }
}
