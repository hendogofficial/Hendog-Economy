package com.hendog.economy;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

/** /bal [player] */
final class BalCommand implements TabExecutor {
    private final HendogEconomyPlugin plugin;

    BalCommand(HendogEconomyPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        EconomyService eco = plugin.economy();
        Messages msg = plugin.messages();
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                msg.send(sender, "players-only");
                return true;
            }
            long b = eco.balance(p.getUniqueId());
            msg.send(sender, "balance-self", "amount", plugin.money(b), "exact", plugin.exactSuffix(b));
            return true;
        }
        if (!sender.hasPermission("hendogeconomy.bal.others")) {
            msg.send(sender, "no-permission");
            return true;
        }
        Optional<UUID> id = eco.find(args[0]);
        if (id.isEmpty()) {
            msg.send(sender, "player-not-found", "player", args[0]);
            return true;
        }
        long b = eco.balance(id.get());
        msg.send(sender, "balance-other", "player", eco.nameOf(id.get()), "amount", plugin.money(b), "exact", plugin.exactSuffix(b));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) out.add(p.getName());
            }
        }
        return out;
    }
}
