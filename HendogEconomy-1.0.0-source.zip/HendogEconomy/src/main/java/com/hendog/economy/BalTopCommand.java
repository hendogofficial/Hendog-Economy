package com.hendog.economy;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

import java.util.List;

/** /baltop [page] */
final class BalTopCommand implements TabExecutor {
    private static final int PER_PAGE = 10;
    private final HendogEconomyPlugin plugin;

    BalTopCommand(HendogEconomyPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        EconomyService eco = plugin.economy();
        Messages msg = plugin.messages();
        int total = eco.count();
        if (total == 0) {
            msg.send(sender, "baltop-empty");
            return true;
        }
        int pages = Math.max(1, (total + PER_PAGE - 1) / PER_PAGE);
        int page = 1;
        if (args.length > 0) {
            try {
                page = Integer.parseInt(args[0]);
            } catch (NumberFormatException ignored) {
                page = 1;
            }
        }
        page = Math.max(1, Math.min(page, pages));
        int offset = (page - 1) * PER_PAGE;
        msg.send(sender, "baltop-header", "page", String.valueOf(page), "pages", String.valueOf(pages));
        List<EconomyService.Row> rows = eco.top(offset, PER_PAGE);
        for (int i = 0; i < rows.size(); i++) {
            EconomyService.Row r = rows.get(i);
            msg.send(sender, "baltop-line", "rank", String.valueOf(offset + i + 1), "player", r.name(), "amount", plugin.money(r.balance()));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return List.of();
    }
}
