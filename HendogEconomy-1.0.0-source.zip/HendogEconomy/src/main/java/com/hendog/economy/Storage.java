package com.hendog.economy;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Saves balances in a simple text file (uuid TAB name TAB balance). Writes safely so a crash can't corrupt it. */
public final class Storage {
    public static final class LoadResult {
        public final List<EconomyService.Row> rows;
        public final int skipped;
        LoadResult(List<EconomyService.Row> rows, int skipped) { this.rows = rows; this.skipped = skipped; }
    }

    private Storage() {}

    public static LoadResult load(Path file) throws IOException {
        List<EconomyService.Row> rows = new ArrayList<>();
        int skipped = 0;
        if (!Files.exists(file)) return new LoadResult(rows, 0);
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            if (line.isBlank() || line.startsWith("#")) continue;
            String[] p = line.split("\t", -1);
            if (p.length != 3) { skipped++; continue; }
            try {
                rows.add(new EconomyService.Row(UUID.fromString(p[0].trim()), p[1], Long.parseLong(p[2].trim())));
            } catch (IllegalArgumentException e) {
                skipped++;
            }
        }
        return new LoadResult(rows, skipped);
    }

    public static void save(Path file, List<EconomyService.Row> rows) throws IOException {
        Path dir = file.toAbsolutePath().getParent();
        if (dir != null) Files.createDirectories(dir);
        Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
        List<String> lines = new ArrayList<>(rows.size() + 1);
        lines.add("# HendogEconomy balances: uuid <TAB> name <TAB> balance. Do not edit while the server is running.");
        for (EconomyService.Row r : rows) {
            String name = r.name() == null ? "" : r.name().replace('\t', '_').replace('\n', '_').replace('\r', '_');
            lines.add(r.id() + "\t" + name + "\t" + r.balance());
        }
        Files.write(tmp, lines, StandardCharsets.UTF_8);
        if (Files.exists(file)) Files.copy(file, file.resolveSibling(file.getFileName() + ".bak"), StandardCopyOption.REPLACE_EXISTING);
        try {
            Files.move(tmp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        }
    }
}
