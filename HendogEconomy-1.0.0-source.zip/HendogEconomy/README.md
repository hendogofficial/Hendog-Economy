# HendogEconomy

The money system for your survival server: balances, `/pay`, `/baltop`, and admin tools.
Amounts work the way DonutSMP players expect: `500`, `10k`, `2.5m`, `350M`, `1b`, plus `half` and `all`.

## Commands

| Command | What it does | Who |
|---|---|---|
| `/bal [player]` (`/balance`, `/money`) | Show a balance, e.g. `Balance: $43.2B (43,200,000,000)` | everyone |
| `/pay <player> <amount>` | Pay someone. Amount can be `1k`, `2.5m`, `1b`, `half`, `all` | everyone |
| `/baltop [page]` | Richest players, 10 per page | everyone |
| `/eco give <player> <amount>` | Add money | admins (op) |
| `/eco take <player> <amount>` | Remove money | admins |
| `/eco set <player> <amount>` | Set a balance | admins |
| `/eco reset <player>` | Back to the starting balance | admins |
| `/eco reload` | Reload `config.yml` | admins |

Permissions: `hendogeconomy.bal`, `hendogeconomy.bal.others`, `hendogeconomy.pay`, `hendogeconomy.baltop` (all on by default) and `hendogeconomy.admin` (ops only).

## Getting the .jar (pick ONE way)

**A. Easiest - let GitHub build it (nothing to install)**
1. Make a free GitHub account and create a new repository.
2. Upload everything in this folder (keep the folder structure, including the hidden `.github` folder).
3. Open the **Actions** tab, wait for "Build plugin" to finish (green tick), open the run, and download the **HendogEconomy** file at the bottom. Unzip it: `HendogEconomy.jar` is your plugin.

**B. On your own PC**
Install JDK 21 and Maven, open a terminal in this folder and run `mvn package`. The plugin is `target/HendogEconomy.jar`.

**C. IntelliJ IDEA (free Community edition)**
Open this folder as a Maven project, then Maven panel -> Lifecycle -> `package`.

> The `pom.xml` is set for Minecraft **1.21.11**. If your server is another version, change the line
> `<version>1.21.11-R0.1-SNAPSHOT</version>` to match (for example `1.21.4-R0.1-SNAPSHOT`) and `api-version` in `plugin.yml` if needed.

## Setting up the server
1. Download **Paper** from papermc.io (pick your Minecraft version). You need Java 21.
2. Put the Paper jar in a new folder and start it once: `java -Xmx4G -jar paper-*.jar --nogui`. Accept the EULA in `eula.txt`, start again.
3. Stop the server, drop `HendogEconomy.jar` into the `plugins` folder, start again.
4. Edit `plugins/HendogEconomy/config.yml` (starting money, messages) and run `/eco reload`.
5. Make yourself op from the console: `op YourName`.

## Files it creates (in `plugins/HendogEconomy/`)
- `balances.tsv` - everyone's money. Saved every 5 minutes (if something changed) and when the server stops. A `.bak` copy of the previous save is kept.
- `transactions.log` - one line for every `/pay` and `/eco` action (handy for catching scams or dupes).
- If `balances.tsv` can't be read, the plugin turns itself off instead of overwriting your data.

## Works with the Hendog Auction Mod
The default messages are worded so the mod's balance tracker understands them: `You paid $50M to Bob.`, `Bob paid you $50M.` and `Balance: $43.2B`.

## For your future plugins (auction house, shop, etc.)
In the other plugin's `plugin.yml` add `depend: [HendogEconomy]`, then:

```java
EconomyService eco = HendogEconomyPlugin.get().economy();
if (eco.has(uuid, price)) {
    eco.withdraw(uuid, price);      // returns Result.OK on success
}
eco.deposit(sellerUuid, price);
eco.transfer(buyerUuid, sellerUuid, price);   // atomic: both sides change or neither does
```
All of these are thread-safe and never let a balance go negative or above `max-balance`.

## What was tested
The money logic (parsing `1.5b`, formatting, overflow limits, atomic transfers, saving/loading, a 400,000-transfer stress test where no money is created or lost) and the commands (in a simulated server) all pass.
It has NOT been run on a real Paper server - it was compiled against stand-in classes, not the real Paper API. If your first build shows an error, send it to me and I'll fix it right away.
